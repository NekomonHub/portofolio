<?php
include "php/indexban.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="data/logo.png">
<link rel="stylesheet" href="css/cekbanned.css">
<script src="js/cekbanned.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Check Banned Number</title>
</head>
<body>
<div class="container">
    <h2>Check Number</h2>
    <form method="post" onsubmit="showLoading()">
        <input type="text" name="phone" placeholder="Enter phone number" required>
        <button type="submit">Check</button>
    </form>
    <div id="loading"></div>
    <div>
        <?php if($statusMessage) echo $statusMessage; ?>
    </div>
</div>
<footer>© Copyright by Chitchat Inc</footer>
</body>
</html>
