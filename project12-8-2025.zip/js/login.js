(function(){
  const slides = document.getElementById('slides');
  const slider = document.getElementById('slider');
  const swipeInd = document.getElementById('swipeInd');
  let index = 0;
  function show(i){
    index = i;
    slides.style.transform = `translateX(${ -50 * i }%)`;
    swipeInd.textContent = i === 0 ? 'Swipe → to register' : 'Swipe ← to login';
  } let startX = null;
  slider.addEventListener('touchstart', e => {
    startX = e.touches[0].clientX;
  }, {passive:true});
  slider.addEventListener('touchmove', e => {
    if(startX === null) return;
    const dx = e.touches[0].clientX - startX;
    slides.style.transition = 'none';
    slides.style.transform = `translateX(${ -50*index + (dx/(slider.offsetWidth))*100 }%)`;
  }, {passive:true});
  slider.addEventListener('touchend', e => {
    slides.style.transition = '';
    if(startX === null) return;
    const dx = (e.changedTouches[0].clientX - startX);
    if(dx < -40) show(1);
    else if(dx > 40) show(0);
    else show(index);
    startX = null;
  });
  swipeInd.addEventListener('click', () => show(index ? 0 : 1));
  window.addEventListener('keydown', e => {
    if(e.key === 'ArrowRight') show(1);
    if(e.key === 'ArrowLeft') show(0);
  });
  slides.addEventListener('transitionend', ()=> slides.style.transition = '');
  show(0);
})();
