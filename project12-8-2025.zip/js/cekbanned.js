function showLoading() {
    document.getElementById('loading').style.display = 'block';
}
