    document.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click', function(e){
        const targetId = this.getAttribute('href').slice(1);
        if(!targetId) return;
        const el = document.getElementById(targetId);
        if(el){
          e.preventDefault();
          el.scrollIntoView({behavior:'smooth', block:'start'});
        }
      });
    });

    function animateCounters(){
      document.querySelectorAll('.num').forEach(el=>{
        const target = +el.getAttribute('data-target')||0;
        let cur=0;
        const step=Math.max(1, Math.ceil(target/60));
        const iv=setInterval(()=>{
          cur+=step;
          if(cur>=target){el.textContent=target; clearInterval(iv);}
          else el.textContent=cur;
        },16);
      });
    } const statsEl = document.querySelector('.stats');
    if(statsEl){
      const obs = new IntersectionObserver((entries, o)=>{
        entries.forEach(en=>{
          if(en.isIntersecting){ animateCounters(); o.disconnect(); }
        });
      }, {threshold:0.4});
      obs.observe(statsEl);
    } if(location.hash && document.getElementById(location.hash.slice(1))){
      setTimeout(()=> document.getElementById(location.hash.slice(1)).scrollIntoView({behavior:'smooth'}), 200);
    }
