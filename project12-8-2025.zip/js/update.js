document.addEventListener('DOMContentLoaded', function(){
AOS.init({duration: 700, easing: 'ease-out-cubic', once: true, mirror: false});
    });
    function openCompose(){
      const title = prompt('Judul update (singkat):');
      if(!title) return;
      const body = prompt('Deskripsi singkat:');
      if(body === null) return;
      alert('Untuk sekarang, fitur create update belum langsung menyimpan ke server.\nImplementasi DB diperlukan untuk menyimpan secara permanen.');
    }
