// js/script.js
// SPA behavior, search, recent, open chat, polling, send, settings
(() => {
    const APP = window.__APP__ || {};
    const me = APP.me || 0;
    let currentWith = APP.initialWith || null;
    let pollTimer = null;

    const recentList = document.getElementById('recentList');
    const messagesBox = document.getElementById('messagesBox');
    const chatWithName = document.getElementById('chatWithName');
    const chatWithSub = document.getElementById('chatWithSub');
    const composer = document.getElementById('composer');
    const msgInput = document.getElementById('msgInput');
    const sendBtn = document.getElementById('sendBtn');
    const searchInput = document.getElementById('searchInput');
    const sidebar = document.getElementById('sidebar');
    const backBtn = document.getElementById('backBtn');
    const settingsPanel = document.getElementById('settingsPanel');
    const navHome = document.getElementById('navHome');
    const navSettings = document.getElementById('navSettings');
    const myAvatarWrap = document.getElementById('myAvatarWrap');
    const myDisplayNameEl = document.getElementById('myDisplayName');
    const displayNameInput = document.getElementById('displayNameInput');
    const settingsAvatarImg = document.getElementById('settingsAvatarImg');
    const avatarFile = document.getElementById('avatarFile');
    const saveProfileBtn = document.getElementById('saveProfileBtn');
    const cancelSettingsBtn = document.getElementById('cancelSettingsBtn');
    const bottomNav = document.getElementById('bottomNav');
    const typingIndicator = document.getElementById('typingIndicator');
    const typingText = document.querySelector('.typing-text');

    function apiGET(params){
        return fetch('index.php?' + new URLSearchParams(params)).then(r=>r.json());
    }
    function apiPOST(body){
        return fetch('index.php', {
            method:'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: new URLSearchParams(body)
        }).then(r=>r.json());
    }
    function escapeHtml(s){
        return String(s||'')
            .replace(/&/g,'&amp;')
            .replace(/</g,'&lt;')
            .replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;')
            .replace(/'/g,'&#39;');
    }

    /* ---------- Recent list ---------- */
    function loadRecent(){
        apiGET({action:'chats'}).then(list=>{
            recentList.innerHTML = '';
            if(!list || list.length===0){
                recentList.innerHTML = '<div style="padding:12px;color:#7a98b6">No recent chats yet.</div>';
                return;
            }
            list.forEach(item=>{
                const el = document.createElement('div');
                el.className = 'chat-item' + (currentWith==item.id ? ' active' : '');
                el.dataset.id = item.id;
                const avatar = item.avatar ? item.avatar : (APP.defaultAvatar || 'uploads/avatars/user.png');
                el.innerHTML = `<div class="c-avatar"><img src="${escapeHtml(avatar)}" alt=""></div>
                    <div class="c-meta">
                        <div class="c-name">${escapeHtml(item.name || item.phone)}</div>
                        <div class="c-last">${escapeHtml(item.last_message)}</div>
                    </div>`;
                el.addEventListener('click', ()=> openChat(item.id, item.name || item.phone, true));
                recentList.appendChild(el);
            });
        }).catch(e=>{
            console.error('loadRecent error', e);
        });
    }

    /* ---------- Search ---------- */
    let searchTimer = null;
    if (searchInput) {
        searchInput.addEventListener('input', ()=>{
            clearTimeout(searchTimer);
            const q = searchInput.value.trim();
            searchTimer = setTimeout(()=>{
                if(q === '') { loadRecent(); return; }
                apiGET({action:'search', q}).then(res=>{
                    recentList.innerHTML = '';
                    if(!res || res.length===0){
                        recentList.innerHTML = '<div style="padding:12px;color:#7a98b6">No users found.</div>';
                        return;
                    }
                    res.forEach(u=>{
                        const el = document.createElement('div');
                        el.className = 'chat-item';
                        const avatar = u.avatar ? u.avatar : (APP.defaultAvatar || 'uploads/avatars/user.png');
                        el.innerHTML = `<div class="c-avatar"><img src="${escapeHtml(avatar)}" alt=""></div>
                            <div class="c-meta">
                                <div class="c-name">${escapeHtml(u.name || u.phone)}</div>
                                <div class="c-last">Tap to open chat</div>
                            </div>`;
                        el.addEventListener('click', ()=> openChat(u.id, u.name || u.phone, true));
                        recentList.appendChild(el);
                    });
                }).catch(e=>{
                    console.error('search error', e);
                    recentList.innerHTML = '<div style="padding:12px;color:#7a98b6">Search failed.</div>';
                });
            }, 240);
        });
    }

    /* ---------- Open Chat ---------- */
    function openChat(id, phone, pushState){
        settingsPanel.style.display = 'none';
        navSettings.classList.remove('active');
        currentWith = id;
        chatWithName.textContent = phone;
        chatWithSub.textContent = '...';
        composer.style.display = 'flex';
        messagesBox.innerHTML = '';
        msgInput.value = '';

        if(window.innerWidth <= 900){
            sidebar.classList.add('hidden-on-mobile');
            backBtn.style.display = 'inline-block';
            bottomNav.style.display = 'none';
            bottomNav.classList.add('hidden');
        } else {
            backBtn.style.display = 'none';
        }

        if(pushState) {
            const url = new URL(window.location);
            url.searchParams.set('with', id);
            history.pushState({with:id}, '', url);
        }

        [...recentList.querySelectorAll('.chat-item')].forEach(it=>it.classList.toggle('active', it.dataset.id==id));
        loadMessages();
        if(pollTimer) clearInterval(pollTimer);
        pollTimer = setInterval(loadMessages, 2000);
    }

    /* ---------- Load messages ---------- */
    function loadMessages(){
        if(!currentWith) return;
        apiGET({action:'fetch', with: currentWith}).then(list=>{
            messagesBox.innerHTML = '';
            if(!list) return;
            list.forEach(m=>{
                const d = document.createElement('div');
                d.className = 'msg ' + (m.sender_id == me ? 'me' : 'other');
                const senderName = m.sender_name || (m.sender_id==me ? document.getElementById('myDisplayName').textContent : '');
                const avatarSrc = m.sender_avatar ? m.sender_avatar : (APP.defaultAvatar || 'uploads/avatars/user.png');
                const avatarHtml = `<div class="avatar-small"><img src="${escapeHtml(avatarSrc)}" alt=""></div>`;
                const nameHtml = `<span class="sender-name">${escapeHtml(senderName || (m.sender_id==me ? document.getElementById('myDisplayName').textContent : ''))}</span>`;
                const text = escapeHtml(m.message);
                const time = new Date(m.created_at).toLocaleString();
                d.innerHTML = `${avatarHtml}${nameHtml}<div class="text">${text}</div><span class="meta">${escapeHtml(time)}</span>`;
                messagesBox.appendChild(d);
            });
            messagesBox.scrollTop = messagesBox.scrollHeight;
            if(list.length) chatWithSub.textContent = 'Last: ' + new Date(list[list.length-1].created_at).toLocaleString();
            else chatWithSub.textContent = 'No messages yet';
            loadRecent();
        }).catch(e=>{
            console.error('loadMessages error', e);
        });
    }

    /* ---------- Send message ---------- */
    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }
    if (msgInput) {
        msgInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ e.preventDefault(); sendMessage(); } });
    }

    function sendMessage(){
        const txt = msgInput.value.trim();
        if(!txt || !currentWith) return;
        apiPOST({action:'send', receiver_id: currentWith, message: txt}).then(res=>{
            if(res && res.ok){
                msgInput.value = '';
                loadMessages();
            }
        }).catch(e=>{
            console.error('sendMessage error', e);
        });
    }

    /* ---------- Settings ---------- */
    if (navSettings) {
        navSettings.addEventListener('click', ()=>{
            settingsPanel.style.display = 'block';
            composer.style.display = 'none';
            messagesBox.innerHTML = '';
            chatWithName.textContent = 'Settings';
            chatWithSub.textContent = '';
            bottomNav.style.display = 'none';
            bottomNav.classList.add('hidden');
            backBtn.style.display = 'inline-block';
            sidebar.classList.remove('hidden-on-mobile');
            displayNameInput.value = document.getElementById('myDisplayName').textContent || '';
            settingsAvatarImg.src = document.querySelector('#myAvatarWrap img').src || (APP.defaultAvatar || 'uploads/avatars/user.png');
            setTimeout(()=> { displayNameInput.focus(); }, 120);
        });
    }

    if (navHome) {
        navHome.addEventListener('click', ()=>{
            settingsPanel.style.display = 'none';
            composer.style.display = 'none';
            messagesBox.innerHTML = '';
            chatWithName.textContent = 'Select a chat';
            chatWithSub.textContent = 'Search phone or pick from recent to start messaging';
            bottomNav.style.display = 'flex';
            bottomNav.classList.remove('hidden');
            sidebar.classList.remove('hidden-on-mobile');
            const url = new URL(window.location);
            url.searchParams.delete('with');
            history.pushState({}, '', url);
            currentWith = null;
            if(pollTimer){ clearInterval(pollTimer); pollTimer = null; }
            loadRecent();
        });
    }

    if (saveProfileBtn) {
        saveProfileBtn.addEventListener('click', ()=>{
            const fd = new FormData();
            fd.append('action','save_profile');
            fd.append('display_name', displayNameInput.value || '');
            if(avatarFile.files && avatarFile.files[0]) fd.append('avatar', avatarFile.files[0]);
            saveProfileBtn.disabled = true;
            saveProfileBtn.textContent = 'Saving...';
            fetch('index.php', { method:'POST', body: fd }).then(r=>r.json()).then(res=>{
                saveProfileBtn.disabled = false;
                saveProfileBtn.textContent = 'Save';
                if(res && res.ok){
                    document.querySelector('#myAvatarWrap img').src = res.user.avatar ? res.user.avatar : (APP.defaultAvatar || 'uploads/avatars/user.png');
                    document.getElementById('myDisplayName').textContent = res.user.name ? res.user.name : 'You';
                    settingsPanel.style.display = 'none';
                    navSettings.classList.remove('active');
                    bottomNav.style.display = 'flex';
                    bottomNav.classList.remove('hidden');
                    backBtn.style.display = 'none';
                    loadRecent();
                } else {
                    alert('Failed to save profile');
                    bottomNav.style.display = 'flex';
                    bottomNav.classList.remove('hidden');
                }
            }).catch(err=>{
                saveProfileBtn.disabled = false;
                saveProfileBtn.textContent = 'Save';
                alert('Upload error');
                bottomNav.style.display = 'flex';
                bottomNav.classList.remove('hidden');
            });
        });
    }

    if (cancelSettingsBtn) {
        cancelSettingsBtn.addEventListener('click', ()=>{
            settingsPanel.style.display = 'none';
            bottomNav.style.display = 'flex';
            bottomNav.classList.remove('hidden');
            backBtn.style.display = 'none';
        });
    }

    /* ---------- Back button ---------- */
    if (backBtn) {
        backBtn.addEventListener('click', ()=>{
            sidebar.classList.remove('hidden-on-mobile');
            backBtn.style.display = 'none';
            const url = new URL(window.location);
            url.searchParams.delete('with');
            history.pushState({}, '', url);
            currentWith = null;
            chatWithName.textContent = 'Select a chat';
            chatWithSub.textContent = 'Search phone or pick from recent to start messaging';
            composer.style.display = 'none';
            messagesBox.innerHTML = '';
            loadRecent();
            if(pollTimer){ clearInterval(pollTimer); pollTimer = null; }
            bottomNav.style.display = 'flex';
            bottomNav.classList.remove('hidden');
        });
    }

    /* ---------- popstate handling ---------- */
    window.addEventListener('popstate', (e)=>{
        const stateWith = (e.state && e.state.with) ? e.state.with : (new URL(window.location)).searchParams.get('with');
        if(stateWith){
            fetch('index.php?action=fetch&with='+encodeURIComponent(stateWith)).then(r=>r.json()).then(list=>{
                let headerPhone = 'Chat';
                const node = [...recentList.querySelectorAll('.chat-item')].find(n => n.dataset.id == stateWith);
                if(node) headerPhone = node.querySelector('.c-name').textContent;
                openChat(stateWith, headerPhone, false);
            });
        } else {
            sidebar.classList.remove('hidden-on-mobile');
            backBtn.style.display = 'none';
            currentWith = null;
            chatWithName.textContent = 'Select a chat';
            chatWithSub.textContent = 'Search phone or pick from recent to start messaging';
            composer.style.display = 'none';
            messagesBox.innerHTML = '';
            loadRecent();
            if(pollTimer){ clearInterval(pollTimer); pollTimer = null; }
            bottomNav.style.display = 'flex';
            bottomNav.classList.remove('hidden');
        }
    });

    /* ---------- notifications & polling ---------- */
    const defaultAvatar = APP.defaultAvatar || 'uploads/avatars/user.png';
    let lastMessageIds = {};
    if (Notification && Notification.permission !== "granted") {
        Notification.requestPermission();
    }
    let lastCheck = new Date().toISOString();

    function checkNewMessagesAPI(){
        fetch('index.php?action=check_new_messages&since=' + lastCheck)
            .then(res => res.json())
            .then(data => {
                data.forEach(msg => {
                    if (Notification.permission === "granted") {
                        new Notification("New message from " + msg.sender_name, {
                            body: msg.message,
                            icon: msg.sender_avatar || defaultAvatar
                        });
                    }
                });
                if (data.length > 0) {
                    lastCheck = new Date().toISOString();
                }
            })
            .catch(err => {});
    }
    setInterval(checkNewMessagesAPI, 5000);
    checkNewMessagesAPI();

    /* typing & helper */
    let typingTimeout;
    const composerInput = document.querySelector('.composer input[type="text"]');
    if (composerInput) {
        composerInput.addEventListener('input', () => {
            if (!currentWith) return;
            fetch(`?action=typing&with=${currentWith}`).catch(e=>{});
        });
    }

    /* initial load */
    loadRecent();
    if(currentWith){
        fetch('index.php?action=fetch&with='+encodeURIComponent(currentWith)).then(r=>r.json()).then(list=>{
            setTimeout(()=>{
                const node = [...recentList.querySelectorAll('.chat-item')].find(n => n.dataset.id == currentWith);
                const phone = node ? node.querySelector('.c-name').textContent : ('Chat #' + currentWith);
                openChat(currentWith, phone, false);
            }, 300);
        });
    }

    // Popup helpers (these were inline before)
    window.showPopup = function(number){
        const popup = document.getElementById('phonePopup');
        document.getElementById('popupNumber').innerText = number;
        popup.style.display = 'block';
        window.currentNumber = number;
    };
    window.closePopup = function(){
        document.getElementById('phonePopup').style.display = 'none';
        window.currentNumber = null;
    };
    window.startChat = function(){
        if(!window.currentNumber) return;
        // If the number is not an ID we need to search and navigate; simple approach: go to index.php?with=<number>
        window.location.href = 'index.php?with=' + encodeURIComponent(window.currentNumber);
        closePopup();
    };
    window.startCall = function(){
        if(!window.currentNumber) return;
        alert('Simulasi call ke '+window.currentNumber);
    };

})();
