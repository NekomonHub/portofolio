<?php
session_start();

include 'iron.php';
// redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$me = (int)$_SESSION['user_id'];
$myphone = $_SESSION['phone'] ?? 'You';

$pdo = new PDO('sqlite:' . __DIR__ . '/database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  

if(isset($_SESSION['user_id'])){
    $stmt = $pdo->prepare("SELECT banned_until FROM banned_users WHERE user_id = :uid LIMIT 1");
    $stmt->execute([':uid'=>$_SESSION['user_id']]);
    $banned = $stmt->fetch(PDO::FETCH_ASSOC);
    if($banned){
        $now = time();
        $until = $banned['banned_until'] ? strtotime($banned['banned_until']) : null;
    
        if(!$until || $until > $now){
            $waktu = $until ? date('Y-m-d H:i', $until) : 'permanently';
            $isPermanent = !$until;
    
            $remaining = $until ? $until - $now : null;
    
            ?>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #1a1a1a;
        color: #fff;
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .banned-box {
        background: #2c2c2c;
        padding: 50px 30px;
        border-radius: 20px;
        text-align: center;
        width: 90%;
        max-width: 600px;  /* cocok di hampir semua Android */
        box-shadow: 0 0 25px rgba(0,0,0,0.4);
        font-size: 20px;
        position: relative;
    }
    .banned-box img.icon {
        width: 80px;
        height: 80px;
        margin-bottom: 25px;
    }
    .banned-box h1 { 
        color: #ff4d4d;
        margin-bottom: 20px;
        font-size: 36px;
    }
    .banned-box p { 
        font-size: 22px;
        margin-bottom: 30px;
        line-height: 1.6;
    }
    .banned-box a {
        display: inline-block;
        padding: 20px 40px;
        background: #ff4d4d;
        color: #fff;
        border-radius: 12px;
        text-decoration: none;
        font-weight: bold;
        font-size: 22px;
    }
</style>

            <div class="banned-box">
                <h1>WARNING!</h1>
                <p>
                    <?php 
                    if($isPermanent){
                        echo "Your account has been banned permanently.<br>Register a new number to continue.";
                    } else {
                        echo "Your account has been banned until <strong>$waktu</strong>.<br>";
                        echo "Remaining: <span id='countdown'></span>";
                    }
                    ?>
                </p>
                <a href="login.php"><?php echo $isPermanent ? "Register / Login" : "Wait"; ?></a>
            </div>
    
            <?php if(!$isPermanent && $remaining > 0){ ?>
            <script>
                let remaining = <?php echo $remaining; ?>;
                const countdownEl = document.getElementById('countdown');
    
                function updateCountdown(){
                    if(remaining <= 0){
                        location.reload(); // otomatis buka banned
                        return;
                    }
                    let h = Math.floor(remaining/3600);
                    let m = Math.floor((remaining%3600)/60);
                    let s = remaining % 60;
                    countdownEl.textContent = h + "h " + m + "m " + s + "s";
                    remaining--;
                }
                setInterval(updateCountdown, 1000);
                updateCountdown();
            </script>
            <?php } ?>
    
            <?php
            exit;
        } else {
            // expired ban, hapus
            $stmt = $pdo->prepare("DELETE FROM banned_users WHERE user_id = :uid");
            $stmt->execute([':uid'=>$me]);
        }
    }
}




// pastiin tabel ada (compatible dengan login.php)
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password TEXT,
    remember_token TEXT,
    created_at TEXT
)");
$pdo->exec("CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)");

// ensure additional columns exist (name, avatar)
$cols = $pdo->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_ASSOC);
$colNames = array_column($cols, 'name');
if (!in_array('name', $colNames)) {
    try { $pdo->exec("ALTER TABLE users ADD COLUMN name TEXT"); } catch (Exception $e) {}
}
if (!in_array('avatar', $colNames)) {
    try { $pdo->exec("ALTER TABLE users ADD COLUMN avatar TEXT"); } catch (Exception $e) {}
}

// make upload dir
$uploadDir = __DIR__ . '/uploads/avatars';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
$defaultAvatar = 'user.png'; // make sure this file exists in the project root or change path



$avatarSrc = $user['avatar'] ?? 'uploads/avatars/user.png';

// ---------- AJAX endpoints ----------
if (isset($_GET['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_GET['action'];

    if ($action === 'search') {
        $q = trim($_GET['q'] ?? '');
        $stmt = $pdo->prepare("SELECT id, phone, name, avatar FROM users WHERE (phone LIKE :q OR name LIKE :q) AND id != :me ORDER BY phone LIMIT 50");
        $stmt->execute([':q' => "%$q%", ':me' => $me]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        exit;
    }

    if ($action === 'chats') {
        // ambil messages yang melibatkan user, urut dari terbaru => dedupe per counterpart
        $stmt = $pdo->prepare("SELECT * FROM messages WHERE sender_id = :me OR receiver_id = :me ORDER BY datetime(created_at) DESC, id DESC");
        $stmt->execute([':me' => $me]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $seen = [];
        $list = [];
        foreach ($rows as $r) {
            $other = ($r['sender_id'] == $me) ? $r['receiver_id'] : $r['sender_id'];
            if (isset($seen[$other])) continue;
            $u = $pdo->prepare("SELECT id, phone, name, avatar FROM users WHERE id = :id LIMIT 1");
            $u->execute([':id' => $other]);
            $user = $u->fetch(PDO::FETCH_ASSOC);
            if (!$user) continue;
            $list[] = [
                'id' => (int)$user['id'],
                'phone' => $user['phone'],
                'name' => $user['name'] ?? null,
                'avatar' => $user['avatar'] ?? null,
                'last_message' => $r['message'],
                'created_at' => $r['created_at'],
                'is_sender' => $r['sender_id'] == $me ? 1 : 0
            ];
            $seen[$other] = true;
        }
        echo json_encode($list);
        exit;
        
        if ($action === 'typing') {
            $other = (int)($_GET['with'] ?? 0);
            if (!$other) { echo json_encode(['typing'=>false]); exit; }
        
            // simpan status typing sementara di session
            $_SESSION['typing'][$other] = time();
            echo json_encode(['ok'=>true]);
            exit;
        }
if ($action === 'check_new_messages') {
    $since = $_GET['since'] ?? date('c', time()-60); // default cek 60 detik terakhir
    $stmt = $pdo->prepare("
        SELECT m.id, m.message, m.sender_id, u.name AS sender_name, u.avatar AS sender_avatar
        FROM messages m
        LEFT JOIN users u ON u.id = m.sender_id
        WHERE m.receiver_id = :me AND datetime(m.created_at) > :since
        ORDER BY datetime(m.created_at) ASC
    ");
    $stmt->execute([':me'=>$me, ':since'=>$since]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
        
    }

    if ($action === 'fetch') {
        $other = (int)($_GET['with'] ?? 0);
        if (!$other) { echo json_encode([]); exit; }
        // return messages + sender info (name, avatar) per message to simplify client rendering
        $stmt = $pdo->prepare("SELECT m.id, m.sender_id, m.receiver_id, m.message, m.created_at,
            u.name AS sender_name, u.avatar AS sender_avatar
            FROM messages m
            LEFT JOIN users u ON u.id = m.sender_id
            WHERE (m.sender_id = :me AND m.receiver_id = :other) OR (m.sender_id = :other AND m.receiver_id = :me)
            ORDER BY datetime(m.created_at) ASC, m.id ASC");
        $stmt->execute([':me' => $me, ':other' => $other]);
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($res);
        exit;

        // Sebelum: hanya ambil messages dari sender_id != 0
        $stmt = $pdo->prepare("
            SELECT m.id, m.sender_id, m.receiver_id, m.message, m.created_at,
                   u.name AS sender_name, u.avatar AS sender_avatar
            FROM messages m
            LEFT JOIN users u ON u.id = m.sender_id
            WHERE (m.sender_id = :me AND m.receiver_id = :other) 
               OR (m.sender_id = :other AND m.receiver_id = :me)
            ORDER BY datetime(m.created_at) ASC
        ");
        
        // Sesudah: handle sender_id = 0
        $stmt = $pdo->prepare("
            SELECT m.id, m.sender_id, m.receiver_id, m.message, m.created_at,
                   CASE WHEN m.sender_id = 0 THEN 'SYSTEM' ELSE u.name END AS sender_name,
                   CASE WHEN m.sender_id = 0 THEN 'uploads/avatars/system.png' ELSE u.avatar END AS sender_avatar
            FROM messages m
            LEFT JOIN users u ON u.id = m.sender_id
            WHERE (m.sender_id = :me AND m.receiver_id = :other) 
               OR (m.sender_id = :other AND m.receiver_id = :me)
            ORDER BY datetime(m.created_at) ASC
        ");

$stmt = $pdo->prepare("
    SELECT m.id, m.sender_id, m.receiver_id, m.message, m.created_at,
           CASE WHEN m.sender_id = 0 THEN 'SYSTEM' ELSE u.name END AS sender_name,
           CASE WHEN m.sender_id = 0 THEN 'uploads/avatars/system.png' ELSE u.avatar END AS sender_avatar
    FROM messages m
    LEFT JOIN users u ON u.id = m.sender_id
    WHERE (m.sender_id = :me AND m.receiver_id = :other) 
       OR (m.sender_id = :other AND m.receiver_id = :me)
    ORDER BY datetime(m.created_at) ASC
");





        
    }

    if ($action === 'get_user') {
        $uid = (int)($_GET['id'] ?? 0);
        if (!$uid) { echo json_encode(null); exit; }
        $u = $pdo->prepare("SELECT id, phone, name, avatar FROM users WHERE id = :id LIMIT 1");
        $u->execute([':id'=>$uid]);
        $row = $u->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            echo json_encode($row);
        } else echo json_encode(null);
        exit;
    }

    echo json_encode([]);
    exit;
}

// message send (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send') {
    header('Content-Type: application/json; charset=utf-8');
    $other = (int)($_POST['receiver_id'] ?? 0);
    $msg = trim($_POST['message'] ?? '');
    if ($other && $msg !== '') {
        $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, message, created_at) VALUES (:s,:r,:m,:c)");
        $stmt->execute([
            ':s' => $me,
            ':r' => $other,
            ':m' => $msg,
            ':c' => date('c')
        ]);
        echo json_encode(['ok' => true, 'id' => (int)$pdo->lastInsertId(), 'created_at' => date('c')]);
        exit;
    }
    echo json_encode(['ok' => false]);
    exit;
}

// profile save (settings) - handle file upload + name update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_profile') {
    // return JSON
    header('Content-Type: application/json; charset=utf-8');
    $newName = trim($_POST['display_name'] ?? '');
    $avatarPath = null;

    // handle file upload if exists
    if (!empty($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $tmp = $_FILES['avatar']['tmp_name'];
        $orig = basename($_FILES['avatar']['name']);
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $allowed = ['png','jpg','jpeg','webp'];
        if (!in_array($ext, $allowed)) {
            echo json_encode(['ok'=>false,'error'=>'Invalid file type']); exit;
        }
        $fn = 'avatar_' . $me . '_' . time() . '.' . $ext;
        $dest = $uploadDir . '/' . $fn;
        if (move_uploaded_file($tmp, $dest)) {
            // store relative path from project root
            $avatarPath = 'uploads/avatars/' . $fn;
        }
    }

    // update DB
    $setParts = [];
    $params = [':id'=>$me];
    if ($newName !== '') { $setParts[] = 'name = :name'; $params[':name']=$newName; }
    if ($avatarPath !== null) { $setParts[] = 'avatar = :avatar'; $params[':avatar']=$avatarPath; }

    if (!empty($setParts)) {
        $sql = 'UPDATE users SET ' . implode(', ', $setParts) . ' WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    }

    // return updated user
    $u = $pdo->prepare("SELECT id, phone, name, avatar FROM users WHERE id = :id LIMIT 1");
    $u->execute([':id'=>$me]);
    $row = $u->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['ok'=>true,'user'=>$row]);
    exit;
}

// ---------- page HTML ----------
$initialWith = (int)($_GET['with'] ?? 0);
?><!doctype html>
<html lang="en">
<head>
<link rel="icon" type="image/png" href="data/icon2.png">
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="index.css">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>ChitChat - App</title>





</head>
<body>
<div class="app">
  <div class="sidebar" id="sidebar">
    <div class="top">
      <div class="avatar" id="myAvatarWrap">
        <?php
          // show avatar img if set
          $stmt = $pdo->prepare("SELECT avatar, name FROM users WHERE id = :id LIMIT 1");
          $stmt->execute([':id'=>$me]);
          $meRow = $stmt->fetch(PDO::FETCH_ASSOC);
          $myAvatar = $meRow['avatar'] ?? null;
          $myName = $meRow['name'] ?? null;
          $avatarSrc = $myAvatar ? htmlspecialchars($myAvatar) : $defaultAvatar;
        ?>
        <img src="<?= htmlspecialchars($avatarSrc) ?>" alt="avatar">
      </div>
      <div class="myinfo">
        <div class="name" id="myDisplayName"><?= htmlspecialchars($myName ?: 'You') ?></div>
        <div class="phone" id="myPhone"><?= htmlspecialchars($myphone) ?></div>
      </div>
      <div><a class="logout" href="logout.php">Logout</a></div>
    </div>

    <div class="search">
      <input id="searchInput" placeholder="Search phone or paste number..." autocomplete="off">
    </div>

    <div style="padding:8px 12px;color:#5b7a9a;font-size:13px">Recent</div>
    <div class="recent" id="recentList" aria-live="polite">
      <!-- recent chats loaded by JS -->
    </div>

  </div>

  <div class="main" id="mainArea">
    <div class="header" id="chatHeader">
      <div style="display:flex;align-items:center;gap:12px">
        <button class="back-btn" id="backBtn">Back</button>
        <div>
          <div class="title" id="chatWithName">Select a chat</div>
          <div class="subtitle" id="chatWithSub">Search phone or pick from recent to start messaging</div>
        </div>
      </div>
    </div>

    <div class="window">
      <div class="messages" id="messagesBox" aria-live="polite">
        <!-- messages here -->
      </div>

      
<div class="typing-indicator" style="display:none; font-size:13px; color:#536b88; margin-bottom:4px;">
    <span class="typing-text"></span>
</div>


      <div class="composer" id="composer" style="display:none">
        <input type="text" id="msgInput" placeholder="Type a message..." autocomplete="off">
        <button class="btn-send" id="sendBtn">Send</button>
      </div>

      <div class="settings-panel" id="settingsPanel">
        <h3>Settings</h3>
        <div style="display:flex;gap:12px;align-items:center">
          <div class="avatar-preview">
            <img id="settingsAvatarImg" src="<?= htmlspecialchars($avatarSrc) ?>" alt="avatar">
          </div>
          <div style="flex:1">
            <form id="settingsForm" method="post" enctype="multipart/form-data">
              <input type="hidden" name="action" value="save_profile">
              <div style="margin-bottom:10px">
                <label style="display:block;font-size:13px;margin-bottom:6px">Display name</label>
                <input name="display_name" id="displayNameInput" placeholder="Your name" style="padding:8px;width:100%;border-radius:8px;border:1px solid #eaeef6">
              </div>
              <div style="margin-bottom:10px">
                <label style="display:block;font-size:13px;margin-bottom:6px">Avatar (png/jpg/webp)</label>
                <input type="file" name="avatar" id="avatarFile" accept="image/*">
              </div>
              <div style="display:flex;gap:8px" class="settings-actions">
                <!-- Save button intentionally away from bottom-nav and near form controls -->
                <button type="button" id="saveProfileBtn" class="btn-send">Save</button>
                <button type="button" id="cancelSettingsBtn" style="background:#eee;border:0;padding:8px 12px;border-radius:8px">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>

<div class="bottom-nav" id="bottomNav">
  <div class="nav-inner">
    <div class="bar">
      <button class="btn" id="navHome">Home</button>
      <button class="btn" id="navSettings">Settings</button>
      <button class="btn" id="navHome" onclick="window.location.href='cekbanned.php'">CheckBan</button>
      <button class="btn" id="navHome" onclick="window.location.href='report.php'">Report</button>
    </div>
  </div>
</div>




<!-- Popup container -->
<div id="phonePopup" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
    background:#222;color:#fff;padding:20px;border-radius:12px;box-shadow:0 0 20px rgba(0,0,0,0.5);z-index:999;">
    <p id="popupNumber"></p>
    <button onclick="startChat()">Chat</button>
    <button onclick="startCall()">Call</button>
    <button onclick="closePopup()">Close</button>
</div>

<script>
function showPopup(number){
    document.getElementById('popupNumber').innerText = number;
    document.getElementById('phonePopup').style.display = 'block';
    window.currentNumber = number; // simpan nomor untuk dipakai di tombol
}

function closePopup(){
    document.getElementById('phonePopup').style.display = 'none';
    window.currentNumber = null;
}

function startChat(){
    if(!window.currentNumber) return;
    // arahkan ke chat internal
    window.location.href = 'index.php?with='+window.currentNumber; 
    closePopup();
}

function startCall(){
    if(!window.currentNumber) return;
    alert('Simulasi call ke '+window.currentNumber); // ganti sesuai kebutuhan
}
</script>









<script>
/* JS: SPA behavior, search, recent, open chat, polling, send, settings */
const me = <?= json_encode($me) ?>;
let currentWith = <?= json_encode($initialWith) ?> || null;
let pollTimer = null;


const recentList = document.getElementById('recentList');
const messagesBox = document.getElementById('messagesBox');
const chatWithName = document.getElementById('chatWithName');
const chatWithSub = document.getElementById('chatWithSub');
const composer = document.getElementById('composer');
const msgInput = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');
const searchInput = document.getElementById('searchInput');
const sidebar = document.getElementById('sidebar');
const backBtn = document.getElementById('backBtn');
const settingsPanel = document.getElementById('settingsPanel');
const navHome = document.getElementById('navHome');
const navSettings = document.getElementById('navSettings');
const myAvatarWrap = document.getElementById('myAvatarWrap');
const myDisplayNameEl = document.getElementById('myDisplayName');
const displayNameInput = document.getElementById('displayNameInput');
const settingsAvatarImg = document.getElementById('settingsAvatarImg');
const avatarFile = document.getElementById('avatarFile');
const saveProfileBtn = document.getElementById('saveProfileBtn');
const cancelSettingsBtn = document.getElementById('cancelSettingsBtn');
const bottomNav = document.getElementById('bottomNav');

function apiGET(params){
  return fetch('index.php?' + new URLSearchParams(params)).then(r=>r.json());
}
function apiPOST(body){
  return fetch('index.php', {
    method:'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: new URLSearchParams(body)
  }).then(r=>r.json());
}

function escapeHtml(s){
  return String(s||'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

/* ---------- Recent list ---------- */
function loadRecent(){
  apiGET({action:'chats'}).then(list=>{
    recentList.innerHTML = '';
    if(!list || list.length===0){
      recentList.innerHTML = '<div style="padding:12px;color:#7a98b6">No recent chats yet.</div>';
      return;
    }
    list.forEach(item=>{
      const el = document.createElement('div');
      el.className = 'chat-item' + (currentWith==item.id ? ' active' : '');
      el.dataset.id = item.id;
      const avatar = item.avatar ? item.avatar : '<?= $defaultAvatar ?>';
      el.innerHTML = `<div class="c-avatar"><img src="${escapeHtml(avatar)}" alt=""></div>
        <div class="c-meta">
          <div class="c-name">${escapeHtml(item.name || item.phone)}</div>
          <div class="c-last">${escapeHtml(item.last_message)}</div>
        </div>`;
      el.addEventListener('click', ()=> openChat(item.id, item.name || item.phone, true));
      recentList.appendChild(el);
    });
  });
}

/* ---------- Search ---------- */
let searchTimer = null;
searchInput.addEventListener('input', ()=>{
  clearTimeout(searchTimer);
  const q = searchInput.value.trim();
  searchTimer = setTimeout(()=>{
    if(q === '') { loadRecent(); return; }
    apiGET({action:'search', q}).then(res=>{
      recentList.innerHTML = '';
      if(!res || res.length===0){
        recentList.innerHTML = '<div style="padding:12px;color:#7a98b6">No users found.</div>';
        return;
      }
      res.forEach(u=>{
        const el = document.createElement('div');
        el.className = 'chat-item';
        const avatar = u.avatar ? u.avatar : '<?= $defaultAvatar ?>';
        el.innerHTML = `<div class="c-avatar"><img src="${escapeHtml(avatar)}" alt=""></div>
          <div class="c-meta">
            <div class="c-name">${escapeHtml(u.name || u.phone)}</div>
            <div class="c-last">Tap to open chat</div>
          </div>`;
        el.addEventListener('click', ()=> openChat(u.id, u.name || u.phone, true));
        recentList.appendChild(el);
      });
    });
  }, 240);
});

/* ---------- Open Chat (separate page inside index) ---------- */
function openChat(id, phone, pushState){
  // hide settings if open
  settingsPanel.style.display = 'none';
  navSettings.classList.remove('active');

  currentWith = id;
  chatWithName.textContent = phone;
  chatWithSub.textContent = '...';
  composer.style.display = 'flex';
  messagesBox.innerHTML = '';
  msgInput.value = '';

  // On small screens hide sidebar to mimic page navigation
  if(window.innerWidth <= 900){
    sidebar.classList.add('hidden-on-mobile');
    backBtn.style.display = 'inline-block';
    // hide bottom nav on entering chat
    bottomNav.style.display = 'none';
    bottomNav.classList.add('hidden');
  } else {
    backBtn.style.display = 'none';
  }

  if(pushState) {
    const url = new URL(window.location);
    url.searchParams.set('with', id);
    history.pushState({with:id}, '', url);
  }

  // set active class in recent list
  [...recentList.querySelectorAll('.chat-item')].forEach(it=>it.classList.toggle('active', it.dataset.id==id));

  // load messages immediately
  loadMessages();
  // start polling
  if(pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(loadMessages, 2000);
}

/* ---------- Load messages for current chat ---------- */
function loadMessages(){
  if(!currentWith) return;
  apiGET({action:'fetch', with: currentWith}).then(list=>{
    messagesBox.innerHTML = '';
    if(!list) return;
    list.forEach(m=>{
      const d = document.createElement('div');
      d.className = 'msg ' + (m.sender_id == me ? 'me' : 'other');

      const senderName = m.sender_name || (m.sender_id==me ? document.getElementById('myDisplayName').textContent : '');
      const avatarSrc = m.sender_avatar ? m.sender_avatar : '<?= $defaultAvatar ?>';

      // avatar element (small, top corner)
      const avatarHtml = `<div class="avatar-small"><img src="${escapeHtml(avatarSrc)}" alt=""></div>`;

      // show sender name above bubble (for both sides)
      const nameHtml = `<span class="sender-name">${escapeHtml(senderName || (m.sender_id==me ? document.getElementById('myDisplayName').textContent : ''))}</span>`;

      const text = escapeHtml(m.message);
      const time = new Date(m.created_at).toLocaleString();

      d.innerHTML = `${avatarHtml}${nameHtml}<div class="text">${text}</div><span class="meta">${escapeHtml(time)}</span>`;
      messagesBox.appendChild(d);
    });
    // scroll to bottom
    messagesBox.scrollTop = messagesBox.scrollHeight;
    // subtitle: last message time
    if(list.length) chatWithSub.textContent = 'Last: ' + new Date(list[list.length-1].created_at).toLocaleString();
    else chatWithSub.textContent = 'No messages yet';
    // refresh recent list (to reorder)
    loadRecent();
  });
}

/* ---------- Send message ---------- */
sendBtn.addEventListener('click', sendMessage);
msgInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ e.preventDefault(); sendMessage(); } });

function sendMessage(){
  const txt = msgInput.value.trim();
  if(!txt || !currentWith) return;
  apiPOST({action:'send', receiver_id: currentWith, message: txt}).then(res=>{
    if(res && res.ok){
      msgInput.value = '';
      loadMessages();
    }
  });
}

/* ---------- Settings handling ---------- */
navSettings.addEventListener('click', ()=>{
  // open settings view (hide chat UI)
  settingsPanel.style.display = 'block';
  composer.style.display = 'none';
  messagesBox.innerHTML = '';
  chatWithName.textContent = 'Settings';
  chatWithSub.textContent = '';

  // HIDE bottom navbar while in settings (so Save button won't be overlapped)
  bottomNav.style.display = 'none';
  bottomNav.classList.add('hidden');

  // show back button (mobile and desktop) so user can go back
  backBtn.style.display = 'inline-block';

  // make sure sidebar visible on desktop; on mobile keep visible so user can pick contact if desired
  sidebar.classList.remove('hidden-on-mobile');

  // populate current values
  displayNameInput.value = document.getElementById('myDisplayName').textContent || '';
  settingsAvatarImg.src = document.querySelector('#myAvatarWrap img').src || '<?= $defaultAvatar ?>';

  // set focus to input for convenience
  setTimeout(()=> { displayNameInput.focus(); }, 120);
});

navHome.addEventListener('click', ()=>{
  // go back to main recent view
  settingsPanel.style.display = 'none';
  composer.style.display = 'none';
  messagesBox.innerHTML = '';
  chatWithName.textContent = 'Select a chat';
  chatWithSub.textContent = 'Search phone or pick from recent to start messaging';
  bottomNav.style.display = 'flex';
  bottomNav.classList.remove('hidden');
  // show sidebar
  sidebar.classList.remove('hidden-on-mobile');
  // clear url
  const url = new URL(window.location);
  url.searchParams.delete('with');
  history.pushState({}, '', url);
  currentWith = null;
  if(pollTimer){ clearInterval(pollTimer); pollTimer = null; }
  loadRecent();
});

/* Save profile */
saveProfileBtn.addEventListener('click', ()=>{
  const fd = new FormData();
  fd.append('action','save_profile');
  fd.append('display_name', displayNameInput.value || '');
  if(avatarFile.files && avatarFile.files[0]) fd.append('avatar', avatarFile.files[0]);

  saveProfileBtn.disabled = true;
  saveProfileBtn.textContent = 'Saving...';

  fetch('index.php', { method:'POST', body: fd }).then(r=>r.json()).then(res=>{
    saveProfileBtn.disabled = false;
    saveProfileBtn.textContent = 'Save';
    if(res && res.ok){
      // update UI
      document.querySelector('#myAvatarWrap img').src = res.user.avatar ? res.user.avatar : '<?= $defaultAvatar ?>';
      document.getElementById('myDisplayName').textContent = res.user.name ? res.user.name : 'You';
      settingsPanel.style.display = 'none';
      navSettings.classList.remove('active');

      // restore bottom navbar after leaving settings
      bottomNav.style.display = 'flex';
      bottomNav.classList.remove('hidden');

      // ensure back button hidden
      backBtn.style.display = 'none';

      loadRecent();
    } else {
      alert('Failed to save profile');
      // also restore bottom nav in case of error so user can navigate
      bottomNav.style.display = 'flex';
      bottomNav.classList.remove('hidden');
    }
  }).catch(err=>{
    saveProfileBtn.disabled = false;
    saveProfileBtn.textContent = 'Save';
    alert('Upload error');
    bottomNav.style.display = 'flex';
    bottomNav.classList.remove('hidden');
  });
});

cancelSettingsBtn.addEventListener('click', ()=>{
  settingsPanel.style.display = 'none';
  // restore bottom nav
  bottomNav.style.display = 'flex';
  bottomNav.classList.remove('hidden');
  // hide back button
  backBtn.style.display = 'none';
});

/* ---------- Back button handling ---------- */
backBtn.addEventListener('click', ()=>{
  // show sidebar again
  sidebar.classList.remove('hidden-on-mobile');
  backBtn.style.display = 'none';
  // remove ?with param from URL
  const url = new URL(window.location);
  url.searchParams.delete('with');
  history.pushState({}, '', url);
  currentWith = null;
  chatWithName.textContent = 'Select a chat';
  chatWithSub.textContent = 'Search phone or pick from recent to start messaging';
  composer.style.display = 'none';
  messagesBox.innerHTML = '';
  loadRecent();
  if(pollTimer){ clearInterval(pollTimer); pollTimer = null; }
  // show bottom nav
  bottomNav.style.display = 'flex';
  bottomNav.classList.remove('hidden');
});

/* ---------- popstate handling (back/forward) ---------- */
window.addEventListener('popstate', (e)=>{
  const stateWith = (e.state && e.state.with) ? e.state.with : (new URL(window.location)).searchParams.get('with');
  if(stateWith){
    fetch('index.php?action=fetch&with='+encodeURIComponent(stateWith)).then(r=>r.json()).then(list=>{
      let headerPhone = 'Chat';
      const node = [...recentList.querySelectorAll('.chat-item')].find(n => n.dataset.id == stateWith);
      if(node) headerPhone = node.querySelector('.c-name').textContent;
      openChat(stateWith, headerPhone, false);
    });
  } else {
    sidebar.classList.remove('hidden-on-mobile');
    backBtn.style.display = 'none';
    currentWith = null;
    chatWithName.textContent = 'Select a chat';
    chatWithSub.textContent = 'Search phone or pick from recent to start messaging';
    composer.style.display = 'none';
    messagesBox.innerHTML = '';
    loadRecent();
    if(pollTimer){ clearInterval(pollTimer); pollTimer = null; }
    bottomNav.style.display = 'flex';
    bottomNav.classList.remove('hidden');
  }
});

/* ---------- initial ---------- */
loadRecent();
if(currentWith){
  fetch('index.php?action=fetch&with='+encodeURIComponent(currentWith)).then(r=>r.json()).then(list=>{
    setTimeout(()=>{
      const node = [...recentList.querySelectorAll('.chat-item')].find(n => n.dataset.id == currentWith);
      const phone = node ? node.querySelector('.c-name').textContent : ('Chat #' + currentWith);
      openChat(currentWith, phone, false);
    }, 300);
  });
}
</script>

<script>
// ==== Notification Setup ====
const defaultAvatar = '<?php echo $defaultAvatar; ?>';
let lastMessageIds = {}; // simpan ID terakhir per user

// minta izin notifikasi saat pertama load
if (Notification.permission !== "granted") {
    Notification.requestPermission();
}

// fungsi cek pesan baru
function checkNewMessages() {
    fetch('?action=chats')
    .then(res => res.json())
    .then(chats => {
        chats.forEach(chat => {
            const lastId = lastMessageIds[chat.id] || 0;
            // ambil ID message terakhir di chat ini
            fetch(`?action=fetch&with=${chat.id}`)
            .then(res => res.json())
            .then(messages => {
                if (!messages.length) return;
                const newest = messages[messages.length-1];
                if (newest.id > lastId && newest.sender_id != <?php echo $me; ?>) {
                    // pesan baru dari lawan chat
                    if (Notification.permission === "granted") {
                        new Notification("New message from " + (chat.name || chat.phone), {
                            body: newest.message,
                            icon: chat.avatar || defaultAvatar
                        });
                    }
                }
                // update lastMessageIds
                lastMessageIds[chat.id] = messages[messages.length-1].id;
            });
        });
    })
    .catch(err => console.error(err));
}

// polling tiap 7 detik
setInterval(checkNewMessages, 7000);
checkNewMessages(); // langsung cek pas load

///==============\\\

let typingTimeout;
const composer = document.querySelector('.composer input[type="text"]');
const typingIndicator = document.querySelector('.typing-indicator');
const typingText = document.querySelector('.typing-text');
const currentChatId = /* id user yang lagi dibuka */;
composer.addEventListener('input', () => {
    if (!currentChatId) return;
    fetch(`?action=typing&with=${currentChatId}`).catch(e=>console.log(e));
});

setInterval(() => {
    if (!currentChatId) return;
    fetch(`?action=get_user&id=${currentChatId}`)
    .then(res=>res.json())
    .then(data=>{
        if(!data) return;
        const lastTyping = data.last_typing ?? 0;
        const now = Date.now()/1000;
        if(now - lastTyping < 3){ // lawan lagi ngetik
            typingText.textContent = data.name ? data.name + ' is typing...' : 'Someone is typing...';
            typingIndicator.style.display = 'block';
        } else {
            typingIndicator.style.display = 'none';
        }
    }).catch(e=>console.log(e));
}, 1500);

// Minta izin notifikasi saat pertama kali load
if (Notification.permission !== "granted") {
    Notification.requestPermission().then(permission => {
        console.log("Notification permission:", permission);
    });
}

let lastCheck = new Date().toISOString(); // simpan timestamp terakhir

function checkNewMessages() {
    fetch('index.php?action=check_new_messages&since=' + lastCheck)
    .then(res => res.json())
    .then(data => {
        data.forEach(msg => {
            // Tampilkan notifikasi
            if (Notification.permission === "granted") {
                new Notification("New message from " + msg.sender_name, {
                    body: msg.message,
                    icon: msg.sender_avatar || 'uploads/avatars/user.png'
                });
            }
        });
        // update timestamp terakhir
        if (data.length > 0) {
            lastCheck = new Date().toISOString();
        }
    })
    .catch(err => console.error(err));
}

// cek setiap 5 detik
setInterval(checkNewMessages, 5000);


</script>


</body>
</html>
