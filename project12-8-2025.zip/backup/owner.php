<?php
session_start();
$ownerPassword = '176201';
$pdo = new PDO('sqlite:' . __DIR__ . '/database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create tables if not exist
$pdo->exec("
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE,
    password TEXT,
    verified INTEGER DEFAULT 0
);");

$pdo->exec("
CREATE TABLE IF NOT EXISTS banned_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    banned_until TEXT,
    banned_at TEXT DEFAULT CURRENT_TIMESTAMP
);");

// Owner login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['owner_pass'])) {
    if ($_POST['owner_pass'] === $ownerPassword) {
        $_SESSION['is_owner'] = true;
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $message = ['type' => 'error', 'text' => 'Wrong password'];
    }
}

if (!isset($_SESSION['is_owner'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Owner Login</title>
        <style>
            body{font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;background:#f0f0f0}
            form{background:#fff;padding:20px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);width:90%;max-width:400px}
            input,button,select{width:100%;padding:10px;margin:8px 0;border-radius:5px;border:1px solid #ccc}
            button{background:#007bff;color:#fff;border:none;cursor:pointer}
            .error{color:#f00}
        </style>
    </head>
    <body>
        <form method="post">
            <h2>Owner Login</h2>
            <input type="password" name="owner_pass" placeholder="Password" required>
            <button type="submit">Login</button>
            <?php if(isset($message)) echo "<p class='{$message['type']}'>{$message['text']}</p>"; ?>
        </form>
    </body>
    </html>
    <?php
    exit;
}

// Helper function
function handleUserAction($pdo, $action, $phone, $duration = null){
    $stmt = $pdo->prepare("SELECT id FROM users WHERE phone = :phone LIMIT 1");
    $stmt->execute([':phone'=>$phone]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$user) return ['type'=>'error','text'=>"User $phone not found"];

    $userId = $user['id'];
    $now = time();

    switch($action){
        case 'ban':
            $bannedUntil = null;
            switch($duration){
                case '1m': $bannedUntil = date('c',$now+60); break;
                case '24h': $bannedUntil = date('c',$now+24*3600); break;
                case '2d': $bannedUntil = date('c',$now+2*24*3600); break;
                case '5d': $bannedUntil = date('c',$now+5*24*3600); break;
                case '2w': $bannedUntil = date('c',$now+14*24*3600); break;
                case '1m-long': $bannedUntil = date('c',$now+30*24*3600); break;
            }
            $stmt = $pdo->prepare("INSERT OR REPLACE INTO banned_users (user_id,banned_until,banned_at) VALUES (:uid,:until,:now)");
            $stmt->execute([':uid'=>$userId,':until'=>$bannedUntil,':now'=>date('c')]);
            return ['type'=>'success','text'=>"User $phone banned for $duration"];
        case 'unban':
            $stmt = $pdo->prepare("DELETE FROM banned_users WHERE user_id=:uid");
            $stmt->execute([':uid'=>$userId]);
            return ['type'=>'success','text'=>"User $phone unbanned"];
        case 'verify':
            $stmt = $pdo->prepare("UPDATE users SET verified=1 WHERE id=:uid");
            $stmt->execute([':uid'=>$userId]);
            return ['type'=>'success','text'=>"User $phone verified"];
    }
}

// Process actions
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    if(isset($_POST['ban_user'])) $message = handleUserAction($pdo,'ban',trim($_POST['phone']),$_POST['duration']??'permanent');
    if(isset($_POST['unban_user'])) $message = handleUserAction($pdo,'unban',trim($_POST['unban_phone']));
    if(isset($_POST['verify_user'])) $message = handleUserAction($pdo,'verify',trim($_POST['verify_phone']));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Owner Panel</title>
<style>
body{font-family:sans-serif;background:#f4f4f4;margin:0;padding:0}
.container{max-width:500px;margin:20px auto;padding:20px;background:#fff;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1)}
h2{margin-top:0;text-align:center}
input,select,button{width:100%;padding:10px;margin:8px 0;border-radius:5px;border:1px solid #ccc}
button{background:#28a745;color:#fff;border:none;cursor:pointer}
.success{color:green}
.error{color:red}
</style>
</head>
<body>
<div class="container">
    <h2>Owner Panel</h2>
    <?php if(isset($message)) echo "<p class='{$message['type']}'>{$message['text']}</p>"; ?>

    <form method="post">
        <h3>Ban User</h3>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <select name="duration">
            <option value="1m">1 Minute</option>
            <option value="24h">24 Hours</option>
            <option value="2d">2 Days</option>
            <option value="5d">5 Days</option>
            <option value="2w">2 Weeks</option>
            <option value="1m-long">1 Month</option>
            <option value="permanent">Permanent</option>
        </select>
        <button type="submit" name="ban_user">Ban User</button>
    </form>

    <form method="post">
        <h3>Unban User</h3>
        <input type="text" name="unban_phone" placeholder="Phone Number" required>
        <button type="submit" name="unban_user">Unban User</button>
    </form>

    <form method="post">
        <h3>Verify User</h3>
        <input type="text" name="verify_phone" placeholder="Phone Number" required>
        <button type="submit" name="verify_user">Verify User</button>
    </form>
</div>
</body>
</html>
