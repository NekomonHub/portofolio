<?php
include "wall.php";
include "php/login.php";
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<link rel="icon" type="image/png" href="data/icon4.png">
<link rel="stylesheet" href="css/reg.css">
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>ChitChat - SignIn</title>
</head>
<body>
<div class="app" role="main">
  <div class="logo">
    <img src="logo.png" alt="logo">
    <h1></h1>
  </div>
  <div class="slider" id="slider">
    <div class="slides" id="slides">
      <!-- LOGIN PANEL -->
      <div class="panel" aria-label="login panel">
        <div class="h">Welcome Back!</div>
        <?php if(!empty($errors)): ?>
          <div class="errors" id="err">
            <?php foreach($errors as $e) echo htmlspecialchars($e)."<br>"; ?>
          </div>
        <?php endif; ?>
        <form method="post" id="loginForm" autocomplete="off">
          <input type="hidden" name="action" value="login">
          <div class="field">
            <label for="phone">Phone number</label>
            <input id="phone" name="phone" type="tel" inputmode="tel" pattern="[0-9+ ]*" placeholder="Input Your Number" required>
          </div>
          <div class="field">
            <label for="password">Password</label>
            <input id="password" name="password" type="password" placeholder="Input Your Password" required>
          </div>
          <div class="field captcha-field">
            <div class="g-recaptcha" id="captcha-login"></div>
          </div>
          <div class="actions">
            <label class="checkbox"><input type="checkbox" name="remember"> Remember me</label>
            <button type="submit" class="btn">Log in</button>
          </div>
          <div class="hint">Swipe right to create an account.</div>
        </form>
      </div>
      <div class="panel" aria-label="register panel">
        <div class="h">Create account</div>
        <form method="post" id="regForm" autocomplete="off">
          <input type="hidden" name="action" value="register">
          <div class="field">
            <label for="email_r">Email</label>
            <input id="email_r" name="email" type="email" placeholder="account@gmail.com" required>
          </div>
          <div class="field">
            <label for="phone_r">Phone number</label>
            <input id="phone_r" name="phone_r" type="tel" inputmode="tel" pattern="[0-9+ ]*" placeholder="Your Number" required>
          </div>
          <div class="field row">
            <div style="flex:1">
              <label for="password_r">Password</label>
              <input id="password_r" name="password_r" type="password" placeholder="Your Password" required>
            </div>
            <div style="flex:1">
              <label for="password2_r">Repeat</label>
              <input id="password2_r" name="password2_r" type="password" placeholder="Your Password" required>
            </div>
          </div>
          <div class="field captcha-field">
            <div class="g-recaptcha" id="captcha-register"></div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:6px">
            <label style="display:flex;align-items:center;gap:8px" class="checkbox">
              <input type="checkbox" name="agree" id="agree"> I accept the Terms &amp; Conditions
            </label>
          </div>
          <div style="margin-top:12px">
            <button type="submit" class="btn">Create account</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
var onloadCallback = function() {
    try {
      if (typeof grecaptcha !== 'undefined') {
        grecaptcha.render('captcha-login', {'sitekey' : '<?= $site_key ?>'});
        grecaptcha.render('captcha-register', {'sitekey' : '<?= $site_key ?>'});
      }
    } catch (e) {
      console && console.warn && console.warn('reCAPTCHA render error', e);
    }
};
</script>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script src="js/login.js"></script>
</body>
</html>
