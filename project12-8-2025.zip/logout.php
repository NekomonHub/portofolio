<?php
// logout.php
session_start();
$pdo = new PDO('sqlite:'.__DIR__.'/database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if(isset($_SESSION['user_id'])){
    // remove token from DB
    $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = :id");
    $stmt->execute([':id'=>$_SESSION['user_id']]);
}

// clear session + cookie
$_SESSION = [];
session_destroy();
setcookie('remember_me', '', time()-3600, '/', '', false, true);

// redirect to login
header('Location: login.php');
exit;
