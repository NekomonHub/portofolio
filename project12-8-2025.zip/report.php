<?php
session_start();

$pdo = new PDO('sqlite:' . __DIR__ . '/database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NULL,
    reporter_phone TEXT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    attachment TEXT NULL,
    status TEXT DEFAULT 'new', -- new / read
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
");

$uploadDir = __DIR__ . '/uploads/reports';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$htaccessPath = $uploadDir . '/.htaccess';
if (!file_exists($htaccessPath)) {
    @file_put_contents($htaccessPath,
        "Options -Indexes\n" .
        "<FilesMatch \"\\.(php|phtml|phar)$\">\n" .
        "  Deny from all\n" .
        "</FilesMatch>\n" .
        "<IfModule mod_headers.c>\n" .
        "  Header set X-Content-Type-Options nosniff\n" .
        "</IfModule>\n"
    );
    // best-effort chmod
    @chmod($htaccessPath, 0644);
}
$indexPath = $uploadDir . '/index.html';
if (!file_exists($indexPath)) {
    @file_put_contents($indexPath, "<!doctype html><meta charset='utf-8'><title>Forbidden</title><h1>403</h1>");
    @chmod($indexPath, 0644);
}

/*
 * ADDED: security config
 */
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024); // 5MB

// mapping of allowed mime => allowed extension(s)
$allowedMimeToExt = [
    'image/png' => ['png'],
    'image/jpeg' => ['jpg','jpeg'],
    'image/webp' => ['webp'],
    'application/pdf' => ['pdf'],
    'text/plain' => ['txt'],
];

// also keep original extension whitelist (kept from your original code)
$allowed = ['png','jpg','jpeg','webp','pdf','txt'];

$errors = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $reporter_phone = trim($_POST['reporter_phone'] ?? '');
    $user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;

    if ($subject === '') $errors[] = "Subject tidak boleh kosong.";
    if ($message === '') $errors[] = "Deskripsi laporan tidak boleh kosong.";

    $attachmentPath = null;
    if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            $tmp = $_FILES['attachment']['tmp_name'];
            $orig = basename($_FILES['attachment']['name']);
            $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));

            // ADDED: check file size server-side
            if ($_FILES['attachment']['size'] > MAX_UPLOAD_BYTES) {
                $errors[] = "File terlalu besar, maksimal 5MB.";
            }

            // ADDED: determine MIME using finfo
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_file($finfo, $tmp) : null;
            if ($finfo) finfo_close($finfo);

            if ($mime === false || $mime === null) {
                $errors[] = "Tidak dapat mendeteksi tipe file. Upload diblokir.";
            } else {
                // ADDED: check mime allowed and that extension matches allowed mime(s)
                if (!isset($allowedMimeToExt[$mime])) {
                    $errors[] = "Attachment tidak valid. Tipe file tidak diizinkan.";
                } else {
                    // ensure extension matches allowed list for the mime type
                    $allowedExtsForMime = $allowedMimeToExt[$mime];
                    if (!in_array($ext, $allowedExtsForMime, true)) {
                        // special-case: jpg vs jpeg mapping (both allowed above)
                        // but if mismatch, prefer server-detected ext
                        $errors[] = "Ekstensi file tidak sesuai dengan isi file.";
                    }
                }
            }

            // ADDED: extra image check -- for images validate via getimagesize
            if (empty($errors) && strpos($mime, 'image/') === 0) {
                $imgInfo = @getimagesize($tmp);
                if ($imgInfo === false) {
                    $errors[] = "File gambar tidak valid atau rusak.";
                }
            }

            // ADDED: quick scan for PHP tags in text files (defense-in-depth)
            if (empty($errors) && (strpos($mime, 'text/') === 0 || $mime === 'application/pdf')) {
                // For text files: read a reasonable chunk to detect <?php
                // For pdf: we do a light check too (some attackers embed scripts), though
                // PDF scanning is limited. This is a heuristic.
                $fh = fopen($tmp, 'rb');
                if ($fh) {
                    $chunk = fread($fh, 8192); // read first 8KB
                    fclose($fh);
                    if (stripos($chunk, '<?php') !== false) {
                        $errors[] = "File mengandung potensi kode PHP dan diblokir.";
                    }
                }
            }

            // Keep original extension whitelist check (your code) as a final defense
            if (!in_array($ext, $allowed)) {
                $errors[] = "Attachment tidak valid. Izinkan: png,jpg,jpeg,webp,pdf,txt.";
            } else {
                if (empty($errors)) {
                    // use random name + timestamp (you already had this pattern)
                    $fn = 'report_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
                    $dest = $uploadDir . '/' . $fn;
                    if (move_uploaded_file($tmp, $dest)) {
                        // ADDED: set safe file perms (owner read/write only, group/world read)
                        @chmod($dest, 0644);
                        $attachmentPath = 'uploads/reports/' . $fn;
                    } else {
                        $errors[] = "Gagal menyimpan file attachment.";
                    }
                }
            }
        } else {
            $errors[] = "Error upload file (kode: ".$_FILES['attachment']['error'].").";
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO reports (user_id, reporter_phone, subject, message, attachment, created_at) VALUES (:uid, :phone, :sub, :msg, :att, :c)");
        $stmt->execute([
            ':uid' => $user_id,
            ':phone' => $reporter_phone ?: null,
            ':sub' => $subject,
            ':msg' => $message,
            ':att' => $attachmentPath,
            ':c' => date('c')
        ]);
        $success = "Laporan berhasil dikirim. Terima kasih sudah melapor.";
        // ADDED: reset POST data after success so form clears (UX)
        $_POST = [];
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Report — ChitChat</title>
  <style>
    :root{--blue:#1e88e5;--card:#fff;--bg:#f4f8ff;--muted:#5b7a9a}
    *{box-sizing:border-box}
    body{margin:0;font-family:Inter,system-ui,Arial;background:var(--bg);color:#123;display:flex;align-items:center;justify-content:center;padding:18px;min-height:100vh}
    .wrap{width:100%;max-width:720px}
    .card{background:var(--card);border-radius:14px;padding:18px;box-shadow:0 10px 30px rgba(10,30,60,0.06)}
    h1{margin:0 0 8px 0;font-size:20px}
    p.lead{margin:0 0 14px 0;color:var(--muted)}
    .field{margin-bottom:12px}
    label{display:block;font-size:13px;color:#456;margin-bottom:6px}
    input[type="text"], textarea, input[type="file"], select{width:100%;padding:12px;border-radius:10px;border:1px solid #e7eefb;background:#fbfdff;outline:none;font-size:15px}
    textarea{min-height:120px;resize:vertical}
    .row{display:flex;gap:8px}
    .btn{display:inline-block;padding:12px 14px;border-radius:12px;background:var(--blue);color:#fff;border:0;font-weight:700;cursor:pointer}
    .btn-ghost{background:transparent;border:1px solid #e2eefb;color:var(--blue)}
    .note{font-size:13px;color:var(--muted)}
    .errors{background:#fff1f2;border:1px solid #ffd6da;color:#7a1921;padding:10px;border-radius:8px;margin-bottom:10px}
    .success{background:#f0fff4;border:1px solid #b6f0c6;color:#0b6b2f;padding:10px;border-radius:8px;margin-bottom:10px}
    @media (max-width:420px){.card{padding:14px}}
    .file-input-wrapper { display:flex; gap:10px; align-items:center; }
    .file-btn {
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:10px 12px;
      border-radius:10px;
      background:var(--blue);
      color:#fff;
      border:0;
      cursor:pointer;
      font-weight:700;
    }
    .file-name { font-size:13px; color:#456; }
    input[type="file"] { display:none; } /* hide default input */
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>Laporkan Pengguna</h1>
      <p class="lead">Isi formulir di bawah ini. Sertakan apa laporan anda</p>

      <?php if(!empty($errors)): ?>
        <div class="errors"><?php foreach($errors as $e) echo htmlspecialchars($e)."<br>"; ?></div>
      <?php endif; ?>
      <?php if($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data" autocomplete="off">
        <div class="field">
          <label for="reporter_phone">Nomor Anda (opsional)</label>
          <input id="reporter_phone" name="reporter_phone" type="text" placeholder="Contoh: 0812..." value="<?= isset($_POST['reporter_phone'])?htmlspecialchars($_POST['reporter_phone']):'' ?>">
        </div>

        <div class="field">
          <label for="subject">Subject</label>
          <input id="subject" name="subject" type="text" placeholder="Subject" required value="<?= isset($_POST['subject'])?htmlspecialchars($_POST['subject']):'' ?>">
        </div>

        <div class="field">
          <label for="message">Pesan</label>
          <textarea id="message" name="message" placeholder="Isi Laporan anda" required><?= isset($_POST['message'])?htmlspecialchars($_POST['message']):'' ?></textarea>
        </div>

        <div class="field">
          <label for="attachment">Opsional</label>
          <div class="file-input-wrapper">
            <label class="file-btn" for="attachmentInput" id="fileBtn">Pilih File</label>
            <span class="file-name" id="fileName"><?= isset($_POST['attachment']) ? htmlspecialchars($_POST['attachment']) : '' ?></span>
            <input id="attachmentInput" name="attachment" type="file" accept=".png,.jpg,.jpeg,.webp,.pdf,.txt">
          </div>

          <div class="note">Sertakan bukti foto Jika ada.</div>
        </div>

        <div style="display:flex;gap:8px;align-items:center;margin-top:8px">
          <button class="btn" type="submit">Kirim Laporan</button>
          <a class="btn-ghost" href="index.php">Batal</a>
        </div>
      </form>
    </div>
  </div>

  <script>
    (function(){
      const input = document.getElementById('attachmentInput');
      const fileBtn = document.getElementById('fileBtn');
      const fileName = document.getElementById('fileName');

      fileBtn.addEventListener('click', function(e){
        input.click();
      });
      input.addEventListener('change', function(){
        if (input.files && input.files.length > 0) {
          let fname = input.files[0].name;
          // show truncated name if too long
          if (fname.length > 40) fname = fname.slice(0,20) + '…' + fname.slice(-15);
          fileName.textContent = fname;
        } else {
          fileName.textContent = '';
        }
      });

      // optional: prevent accidental form resubmission on refresh
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
      }
    })();
  </script>
</body>
</html>
