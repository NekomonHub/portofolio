<!doctype html>
<html lang="en">
<head>
  <link rel="icon" type="image/png" href="data/icon2.png">
  <link rel="stylesheet" type="text/css" href="css/dashboard.css">
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>ChitChat - App</title>
</head>
<body>
  <div class="container">
    <header class="site-header">
      <div class="brand">
        <div class="logo"><img src="data/logo.png" alt="ChitChat Logo"></div>
        <div>
          <h1>ChitChat</h1>
          <p class="muted">Chat cepat, Privasi aman, dan Nyaman</p>
          <p class="mute">Versi 1.02.21 (Beta)</p>
        </div>
      </div>
      <div class="hdr-cta">
        <a class="btn btn-outline" href="login.php">Masuk</a>
      </div>
    </header>

    <!-- main grid -->
    <main class="grid">
      <!-- content left -->
      <section>
        <div class="card hero">
          <div class="hero-cta">
            <div>
              <div class="lead">Cepat, ringan, dan privasi terlindungi.</div>
              <p class="small">ChitChat dirancang untuk anda yang ingin memulai chat dengan orang lain dengan ringan, aman, dan kompleks.</p>
            </div>
          </div>


          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <a class="btn btn-primary" href="login.php">Get Started</a>
            <a class="btn btn-outline" href="#learnmore">Pelajari lebih lanjut</a>
          </div>
        </div>

        <!-- ===== Learn More section inserted here (di dalam file) ===== -->
        <section id="learnmore" class="card" aria-labelledby="learnmore-title" style="margin-top:16px">
          <h2 id="learnmore-title">Pelajari lebih lanjut tentang ChitChat</h2>
          <p class="muted">Panduan singkat tentang cara kerja ChitChat dan keunggulannya.</p>

          <div class="learn-hero" style="margin-top:12px">
            <p><strong>Ringkasan ChitChat</strong></p>
            <p>ChitChat fokus pada kesederhanaan, privasi, dan penggunaan sumber daya yang ringan, cocok untuk anda untuk memulai obrolan dengan orang lain dengan nyaman dan privasi terjaga.</p>

            <div class="learn-grid">
              <div class="card" style="padding:12px">
                <h3 style="margin-bottom:8px">Privasi</h3>
                <p class="muted">ChitChat Dapat melindungi Privasi akun anda dari kejahatan Siber dan Lainnya.</p>
              </div>

              <div class="card" style="padding:12px">
                <h3 style="margin-bottom:8px">Sistem ketat</h3>
                <p class="muted">ChitChat memiliki fitur bawaan untuk mengurangi Risiko XSS.</p>
              </div>

              <div class="card" style="padding:12px">
                <h3 style="margin-bottom:8px">Perlindungan Privasi dan Pelanggaran</h3>
                <p class="muted">ChitChat dapat Mendeteksi Pesan yang Melanggar seperti Penjualan barang terlarang dan Lain sebagainya</code>.</p>
              </div>

              <div class="card" style="padding:12px">
                <h3 style="margin-bottom:8px">Fitur yang Tidak ada di ChitChat</h3>
                <p class="muted">• Tidak adanya fitur Call/VideoCall</p>
                <p class="muted">• Belum adanya fitur mengirim file/Gambar/video</p>
                <p class="muted">• Belum adanya fitur Grup</p>
                <p class="muted">• Belum memiliki fitur post status</p>
                </p>
              </div>
            </div>

            <div style="margin-top:12px">
              <p><strong>Langkah Untuk Memulai</strong></p>
              <ol style="margin:8px 0 0 18px">
                <li>Daftar atau masuk lewat halaman Login / Register.</li>
                <li>Set nama tampilan dan avatar di Settings.</li>
                <li>Cari nomor untuk memulai chat atau buka percakapan terakhir.</li>
              </ol>
            </div>

            <div style="margin-top:12px">
            </div>
          </div>
        </section>
        <!-- ===== end Learn More ===== -->
      <!-- sidebar -->
      <aside class="sidebar">
        <div class="card">
          <h3>Tindakan Cepat</h3>
          <div class="quick-links">
            <a href="login.php" class="btn btn-outline">Login</a>
            <a href="dashboard.php" class="btn">Dashboard</a>
            <a href="#learnmore" class="btn btn-outline">Pelajari lebih lanjut</a>
            <a href="report.php" class="btn btn-outline">Report</a>
          </div>
        </div>

        <div class="card report-box" style="margin-top:12px">
          <p><strong>Laporkan Pelanggaran</strong></p>
          <p class="muted">Laporkan pengguna dan Cantumkan nomor dan deskripsi singkat pelanggaran.</p>
          <a class="report-btn" href="report.php">Report</a>
        </div>
      </aside>
    </main>

    <!-- Footer (latar putih) -->
    <footer class="site-footer">
      <div class="footer-inner">
        <div class="footer-brand">
          <img src="data/logo.png" alt="ChitChat Logo" style="width:72px;height:72px;">
          <p class="muted">ChitChat — Pesan cepat, privat, dan ringan.</p>
          </div>
        </div>

        <div class="footer-links footer-col">
          <h4>Page</h4>
          <a href="login.php">Masuk</a>
          <a href="dashboard.php">Dashboard</a>
          <a href="#learnmore">Cara kerja</a>
        </div>

        <div class="footer-links footer-col">
          <h4>Media Sosial</h4>
          <a href="https://github.com/NekomonHub" target="_blank">GitHub</a>
          <a href="https://youtube.com/" target="_blank">YouTube</a>
        </div>

        <div class="footer-links footer-col">
          <h4>Developer</h4>
          <p class="muted">Zenn - Developer</p>
          <p class="muted">Versi 1.02.21 (Beta)</p>
          <div class="socials" style="margin-top:8px">
            <a href="https://github.com/NekomonHub">GitHub</a>
            <a href="https://wa.me/6285954685828">WhatsApp</a>
          </div>
        </div>
      </div>

      <div class="footer-note center">© 2025 ChitChat. Semua hak dilindungi. Dirancang untuk kenyamanan Anda</div>
    </footer>

  </div>

  <script src="js/dashboard.js"></script>
</body>
</html>
