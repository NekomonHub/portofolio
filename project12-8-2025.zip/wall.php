<?php
$blocked_files = ['database.sqlite', 'owner.php', 'secret.txt'];

$requested_file = basename($_SERVER['REQUEST_URI']);

if (in_array($requested_file, $blocked_files)) {
    http_response_code(403); // Forbidden
    echo "<h1>Access Denied</h1>";
    echo "<p>Kamu ga boleh akses file ini!</p>";
    exit;
}
?>
