<?php
session_start();

// owner password (change if needed)
$ownerPassword = '176201';

// DB init (same DB used by other pages)
$pdo = new PDO('sqlite:' . __DIR__ . '/database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ensure reports table exists (defensive)
$pdo->exec("
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NULL,
    reporter_phone TEXT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    attachment TEXT NULL,
    status TEXT DEFAULT 'new',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
");

// --------- Owner login / logout handling ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['owner_login'])) {
    $pw = $_POST['owner_pass'] ?? '';
    if ($pw === $ownerPassword) {
        $_SESSION['is_owner'] = true;
        // redirect to avoid repost
        header('Location: stay.php');
        exit;
    } else {
        $login_error = "Wrong password.";
    }
}

if (isset($_GET['logout']) && $_GET['logout'] === '1') {
    unset($_SESSION['is_owner']);
    // redirect to login view
    header('Location: stay.php');
    exit;
}

// require owner
if (!isset($_SESSION['is_owner']) || $_SESSION['is_owner'] !== true) {
    // show login form (HTML below) and exit after output
    ?>
    <!doctype html>
    <html lang="id">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title>Owner Login — Stay (Reports)</title>
      <style>
        :root{--bg:#f4f7fb;--card:#fff;--accent:#1e88e5;--muted:#6b87a2}
        *{box-sizing:border-box}
        body{margin:0;font-family:Inter,system-ui,Arial;background:var(--bg);color:#123;display:flex;align-items:center;justify-content:center;height:100vh;padding:16px}
        .card{background:var(--card);padding:22px;border-radius:12px;max-width:420px;width:100%;box-shadow:0 14px 40px rgba(10,30,60,0.06)}
        h2{margin:0 0 8px 0}
        p{margin:0 0 14px 0;color:var(--muted)}
        label{display:block;margin-bottom:6px;font-weight:700}
        input[type="password"]{width:100%;padding:12px;border-radius:8px;border:1px solid #e7eefb;background:#fbfdff}
        .btn{display:inline-block;padding:10px 14px;border-radius:10px;background:var(--accent);color:#fff;border:0;cursor:pointer;margin-top:12px}
        .note{font-size:13px;color:var(--muted);margin-top:10px}
        .err{background:#fff1f2;border:1px solid #ffd6da;color:#7a1921;padding:10px;border-radius:8px;margin-bottom:10px}
      </style>
    </head>
    <body>
      <div class="card" role="main" aria-live="polite">
        <h2>Owner Login</h2>
        <p class="note">This page is restricted. Enter owner password to view reports.</p>
        <?php if(!empty($login_error)): ?>
          <div class="err"><?= htmlspecialchars($login_error) ?></div>
        <?php endif; ?>
        <form method="post" autocomplete="off">
          <label for="owner_pass">Password</label>
          <input id="owner_pass" type="password" name="owner_pass" required>
          <div style="display:flex;gap:8px;align-items:center">
            <button class="btn" name="owner_login" type="submit">Enter</button>
          </div>
        </form>
      </div>
    </body>
    </html>
    <?php
    exit;
}

// ---------- Actions available to owner: mark read/unread, delete ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $action = $_POST['action'];

    if ($action === 'mark_read') {
        $stmt = $pdo->prepare("UPDATE reports SET status = 'read' WHERE id = :id");
        $stmt->execute([':id'=>$id]);
    } elseif ($action === 'mark_unread') {
        $stmt = $pdo->prepare("UPDATE reports SET status = 'new' WHERE id = :id");
        $stmt->execute([':id'=>$id]);
    } elseif ($action === 'delete') {
        // remove attachment file if exists
        $s = $pdo->prepare("SELECT attachment FROM reports WHERE id = :id LIMIT 1");
        $s->execute([':id'=>$id]);
        $r = $s->fetch(PDO::FETCH_ASSOC);
        if ($r && $r['attachment']) {
            $f = __DIR__ . '/' . $r['attachment'];
            if (is_file($f)) @unlink($f);
        }
        $stmt = $pdo->prepare("DELETE FROM reports WHERE id = :id");
        $stmt->execute([':id'=>$id]);
    }

    // redirect to avoid form resubmission
    header('Location: stay.php' . (isset($_GET['view']) ? '?view='.(int)$_GET['view'] : ''));
    exit;
}

// ---------- Fetch list + optional view ----------
$view = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$report = null;
if ($view) {
    $stmt = $pdo->prepare("SELECT * FROM reports WHERE id = :id LIMIT 1");
    $stmt->execute([':id'=>$view]);
    $report = $stmt->fetch(PDO::FETCH_ASSOC);
    // mark read automatically if new
    if ($report && $report['status'] !== 'read') {
        $u = $pdo->prepare("UPDATE reports SET status='read' WHERE id = :id");
        $u->execute([':id'=>$view]);
        $report['status'] = 'read';
    }
}

$listStmt = $pdo->prepare("SELECT id, subject, reporter_phone, status, created_at FROM reports ORDER BY datetime(created_at) DESC LIMIT 500");
$listStmt->execute();
$reports = $listStmt->fetchAll(PDO::FETCH_ASSOC);

// helper
function h($s){ return htmlspecialchars($s); }

?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Stay — Reports Inbox</title>
  <meta name="robots" content="noindex">
  <style>
    :root{
      --bg:#f4f7fb;
      --card:#fff;
      --accent:#1e88e5;
      --muted:#6b87a2;
      --danger:#e63946;
    }
    *{box-sizing:border-box}
    body{margin:0;font-family:Inter,system-ui,Arial;background:var(--bg);color:#123;padding:14px;min-height:100vh}
    .wrap{max-width:1100px;margin:0 auto}
    .header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}
    .card{background:var(--card);border-radius:12px;padding:12px;box-shadow:0 10px 30px rgba(10,30,60,0.06)}
    .layout{display:grid;grid-template-columns:340px 1fr;gap:12px}
    @media (max-width:900px){.layout{grid-template-columns:1fr}}
    .inbox-list{max-height:74vh;overflow:auto}
    .item{padding:12px;border-bottom:1px solid #f0f4fb;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
    .item a{color:inherit;text-decoration:none;display:block;width:100%}
    .left{flex:1}
    .subject{font-weight:700;margin-bottom:6px}
    .meta{font-size:13px;color:var(--muted)}
    .badge-new{background:#fff5e6;color:#a04d00;padding:4px 8px;border-radius:999px;font-weight:800;font-size:12px}
    .toolbar{display:flex;gap:8px}
    .btn{padding:8px 10px;border-radius:10px;border:0;background:var(--accent);color:#fff;cursor:pointer;font-weight:700}
    .btn-muted{background:#eef6ff;color:var(--accent);border:1px solid rgba(30,111,255,0.06)}
    .btn-danger{background:var(--danger);color:#fff}
    .detail{padding:16px}
    .attachment{margin-top:12px}
    .small{color:var(--muted);font-size:13px}
    .center{text-align:center}
    .top-actions{display:flex;gap:8px;align-items:center}
    .search{padding:8px;border-radius:8px;border:1px solid #eef5ff;width:100%}
    button, .btn, input, select { -webkit-tap-highlight-color: transparent; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="header">
      <div>
        <h2 style="margin:0">Stay — Reports Inbox</h2>
        <div class="small">Reports sent from users via <code>report.php</code>. Owner-only page.</div>
      </div>
      <div class="top-actions">
        <form method="get" style="margin:0">
          <input class="search" name="q" placeholder="Search subject or phone..." value="<?= isset($_GET['q']) ? h($_GET['q']) : '' ?>">
        </form>
        <a class="btn-muted" style="padding:8px 12px;border-radius:10px;text-decoration:none;color:var(--accent)" href="stay.php?logout=1">Logout</a>
      </div>
    </div>

    <div class="layout">
      <div class="card inbox-list">
        <div style="padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
          <strong>Recent Reports</strong>
          <span class="small"><?= count($reports) ?> items</span>
        </div>

        <?php if(empty($reports)): ?>
          <div class="center small" style="padding:40px 12px">No reports yet.</div>
        <?php else:
          $q = isset($_GET['q']) ? trim($_GET['q']) : '';
          foreach($reports as $r):
            if ($q !== '') {
              $hay = strtolower($r['subject'].' '.$r['reporter_phone']);
              if (strpos($hay, strtolower($q)) === false) continue;
            }
        ?>
          <a href="stay.php?view=<?= (int)$r['id'] ?>" style="text-decoration:none;color:inherit">
            <div class="item">
              <div class="left">
                <div class="subject"><?= h($r['subject']) ?></div>
                <div class="meta"><?= h($r['reporter_phone'] ?: 'Anonymous') ?> · <?= date('Y-m-d H:i', strtotime($r['created_at'])) ?></div>
              </div>
              <div class="right">
                <?php if($r['status'] === 'new'): ?>
                  <div class="badge-new">NEW</div>
                <?php else: ?>
                  <div class="small">read</div>
                <?php endif; ?>
              </div>
            </div>
          </a>
        <?php endforeach; endif; ?>
      </div>
      <div class="card">
        <?php if(!$report): ?>
          <div class="center" style="padding:40px">
            <div style="font-weight:800;font-size:18px;margin-bottom:6px">Pilih laporan untuk melihat detail</div>
            <div class="small">Klik salah satu item di sebelah kiri untuk membuka pesan seperti tampilan email.</div>
          </div>
        <?php else: ?>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div>
              <div style="font-size:18px;font-weight:800"><?= h($report['subject']) ?></div>
              <div class="small"><?= h($report['reporter_phone'] ?: 'Anonymous') ?> · <?= date('Y-m-d H:i', strtotime($report['created_at'])) ?></div>
            </div>
            <div class="toolbar">
              <form method="post" style="display:inline">
                <input type="hidden" name="id" value="<?= (int)$report['id'] ?>">
                <?php if($report['status'] !== 'read'): ?>
                  <button class="btn" name="action" value="mark_read">Mark as Read</button>
                <?php else: ?>
                  <button class="btn-muted" name="action" value="mark_unread">Mark as Unread</button>
                <?php endif; ?>
              </form>
              <form method="post" style="display:inline" onsubmit="return confirm('Hapus laporan ini?');">
                <input type="hidden" name="id" value="<?= (int)$report['id'] ?>">
                <button class="btn-danger" name="action" value="delete">Delete</button>
              </form>
            </div>
          </div>
          <div class="detail">
            <div style="white-space:pre-wrap;line-height:1.6"><?= h($report['message']) ?></div>
            <?php if(!empty($report['attachment'])): ?>
              <div class="attachment">
                <div class="small">Attachment:</div>
                <?php $ap = __DIR__ . '/' . $report['attachment']; ?>
                <?php if(preg_match('/\.(png|jpe?g|webp)$/i', $report['attachment'])): ?>
                  <img src="<?= h($report['attachment']) ?>" alt="attachment" style="max-width:100%;border-radius:8px;margin-top:8px">
                <?php else: ?>
                  <a class="small" href="<?= h($report['attachment']) ?>" target="_blank">Download attachment</a>
                <?php endif; ?>
              </div>
            <?php endif; ?>
            <div style="margin-top:18px" class="small">Report ID: <?= (int)$report['id'] ?> · Status: <?= h($report['status']) ?></div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>
