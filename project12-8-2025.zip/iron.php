<?php
// ===== Konfigurasi =====
$protectedFile = 'database.sqlite';
$logFile = __DIR__ . '/iron_attempt.log';
$ip = $_SERVER['REMOTE_ADDR'];
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$requestedFile = basename($_SERVER['REQUEST_URI']);
$headers = getallheaders();

// ===== Fungsi block + redirect =====
function cloudflare403Redirect($msg = '403 Forbidden') {
    http_response_code(403);
    echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>$msg</title>
<style>
    body { 
        margin:0; 
        font-family: Arial, sans-serif; 
        display:flex; 
        justify-content:center; 
        align-items:center; 
        height:100vh; 
        background:#1e1e2f; 
        color:#fff; 
        text-align:center; 
    }
    .container { max-width:500px; padding:20px; }
    h1 { font-size:48px; color:#ff3b3b; text-shadow:0 0 10px #ff0000; }
    p { font-size:18px; margin-top:10px; color:#ccc; }
    @media(max-width:600px){
        h1 { font-size:36px; }
        p { font-size:16px; }
    }
</style>
<script>
    // Redirect paksa setelah 5 detik
    setTimeout(function(){
        window.location.href = 'index.php';
    }, 5000);
</script>
</head>
<body>
<div class="container">
    <h1>$msg</h1>
    <p>We are checking your browser...<br>Verification failed. Access denied.<br>
    You will be redirected in 5 seconds.</p>
</div>
</body>
</html>
HTML;
    exit;
}

// ===== Deteksi akses mencurigakan =====
$trigger = false;

// akses database langsung
if($requestedFile === $protectedFile){
    $trigger = true;
}

// user agent mencurigakan
$blockedAgents = ['curl','wget','python-requests','httpclient','libwww','scrapy','postman','java','okhttp','node-fetch','php','go-http-client'];
foreach($blockedAgents as $agent){
    if(stripos($userAgent, $agent) !== false){
        $trigger = true;
        break;
    }
}

// header hilang / aneh
if(empty($headers['Accept']) || (isset($headers['X-Requested-With']) && strtolower($headers['X-Requested-With']) !== 'xmlhttprequest')){
    $trigger = true;
}

// ===== Logging percobaan =====
$logLine = date('c').' - '.$ip.' - UA: '.$userAgent.' - URI: '.$_SERVER['REQUEST_URI'].PHP_EOL;
file_put_contents($logFile, $logLine, FILE_APPEND);

// ===== Jika terdeteksi, tampil halaman 403 + redirect =====
if($trigger){
    cloudflare403Redirect();
}

// ===== Kalau lolos, load halaman biasa =====
// include 'index.php'; // aktifkan kalau mau auto-include halaman
