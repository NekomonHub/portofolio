<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userName = isset($_SESSION['name']) && $_SESSION['name'] !== '' ? $_SESSION['name'] : (isset($_SESSION['phone']) ? $_SESSION['phone'] : 'You');
$updates = [
    [
        'title' => 'Fitur Status Rilis 🚀',
        'date' => '2025-09-02',
        'body' => 'Sekarang kamu bisa upload status berupa gambar, teks, atau video pendek (max 120 detik). Status hilang setelah 24 jam dan ada fitur "Show" untuk lihat siapa yang menonton.',
        'tag' => 'Feature'
    ],
    [
        'title' => 'Perbaikan Upload & UI',
        'date' => '2025-09-01',
        'body' => 'Penanganan error upload ditingkatkan, validasi file lebih ketat, dan tampilannya dipoles supaya lebih smooth di mobile.',
        'tag' => 'Fix'
    ],
    [
        'title' => 'Roadmap: Auto-delete media',
        'date' => '2025-08-28',
        'body' => 'Rencana menambahkan pembersihan otomatis file media status usang via cron job supaya storage tetap rapi.',
        'tag' => 'Roadmap'
    ]
];
?>
