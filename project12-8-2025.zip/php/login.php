<?php
session_start();

$site_key = "6LfK5rwrAAAAAAtgn_4jPtDvp--0TrpkZ2EGETMe"; // site key (public)
$secret_key = "6LfK5rwrAAAAADfx8OYz9AJ26e7ZutUuVqTeMMgy"; // <-- GANTI INI jadi secret key kamu (jangan share)

$pdo = new PDO('sqlite:'.__DIR__.'/database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password TEXT,
    remember_token TEXT,
    created_at TEXT
)");

function redirect($url){ header("Location: $url"); exit; }
function getUserByRemember($pdo, $token){
    $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = :t LIMIT 1");
    $stmt->execute([':t'=>$token]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
function loginUser($user){
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['phone'] = $user['phone'] ?? '';
}

function verifyCaptcha($secret, $response){
    if(empty($response)) return false;

    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = ['secret' => $secret, 'response' => $response];

    if(function_exists('curl_init')){
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        $res = curl_exec($ch);
        curl_close($ch);
        if($res === false) return false;
    } else {
        $opts = ['http' => [
            'method'  => 'POST',
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($data),
            'timeout' => 8
        ]];
        $context = stream_context_create($opts);
        $res = @file_get_contents($url, false, $context);
        if($res === false) return false;
    }

    $json = json_decode($res, true);
    return isset($json['success']) && $json['success'] === true;
}

if(!isset($_SESSION['user_id']) && !empty($_COOKIE['remember_me'])){
    $token = $_COOKIE['remember_me'];
    $user = getUserByRemember($pdo, $token);
    if($user){
        loginUser($user);
        redirect('index.php');
    } else {
        setcookie('remember_me', '', time()-3600, '/', '', false, true);
    }
}

if(isset($_SESSION['user_id'])){
    redirect('index.php');
}

$errors = [];
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $action = $_POST['action'] ?? '';

    if($action === 'login'){
        $phone = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);

        if($phone === '' || $password === ''){
            $errors[] = "Please fill phone and password.";
        }

        $captcha = $_POST['g-recaptcha-response'] ?? '';
        if(!verifyCaptcha($secret_key, $captcha)){
            $errors[] = "Please complete the captcha.";
        }

        if(empty($errors)){
            $stmt = $pdo->prepare("SELECT * FROM users WHERE phone = :phone LIMIT 1");
            $stmt->execute([':phone'=>$phone]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if($user && password_verify($password, $user['password'])){
                loginUser($user);
                if($remember){
                    $token = bin2hex(random_bytes(16));
                    $stmt = $pdo->prepare("UPDATE users SET remember_token = :t WHERE id = :id");
                    $stmt->execute([':t'=>$token, ':id'=>$user['id']]);
                    setcookie('remember_me', $token, time()+60*60*24*30, '/', '', false, true); // 30 days
                }
                redirect('index.php');
            } else {
                $errors[] = "Wrong phone or password.";
            }
        }
    }

    elseif($action === 'register'){
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone_r'] ?? '');
        $pass = $_POST['password_r'] ?? '';
        $pass2 = $_POST['password2_r'] ?? '';
        $agree = isset($_POST['agree']);

        if(!$agree) $errors[] = "You must accept the Terms & Conditions.";
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email.";
        if($phone === '') $errors[] = "Phone required.";
        if(strlen($pass) < 6) $errors[] = "Password must be 6+ chars.";
        if($pass !== $pass2) $errors[] = "Passwords do not match.";

        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :e OR phone = :p LIMIT 1");
        $stmt->execute([':e'=>$email, ':p'=>$phone]);
        if($stmt->fetch()) $errors[] = "Email or phone already registered.";

        $captcha = $_POST['g-recaptcha-response'] ?? '';
        if(!verifyCaptcha($secret_key, $captcha)){
            $errors[] = "Please complete the captcha.";
        }

        if(empty($errors)){
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (email, phone, password, created_at) VALUES (:e,:p,:pw,:c)");
            $stmt->execute([
                ':e'=>$email,
                ':p'=>$phone,
                ':pw'=>$hash,
                ':c'=>date('c')
            ]);
            $id = $pdo->lastInsertId();
            $user = ['id'=>$id, 'phone'=>$phone];
            loginUser($user);
            redirect('index.php');
        }
    }
}
?>
