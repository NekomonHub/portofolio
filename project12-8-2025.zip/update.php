<?php
include "update2.php";
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
  <link rel="stylesheet" href="css/update.css">
  <link rel="icon" type="image/png" href="icon.png">
  <title>Updates — ChitChat</title>
  <link href="https://unpkg.com/aos@next/dist/aos.css" rel="stylesheet">
</head>
<body>
  <main class="wrap" role="main">
    <section class="hero" data-aos="fade-up">
      <div class="hero-left">
        <h1>Latest News & Roadmap</h1>
        <p>Semua pengumuman fitur baru, perbaikan, dan rencana rilis dikumpulkan di sini. Kamu lagi login sebagai <strong><?= htmlspecialchars($userName) ?></strong>.</p>
        <div class="meta">
          <div class="pill">What's new</div>
          <div style="color:var(--muted);font-size:13px">Diperbarui terakhir: <?= date('j F Y') ?></div>
        </div>
      </div>
      <div class="action-bar">
      </div>
    </section>
    <section style="margin-top:18px">
      <div class="grid">
        <?php if(empty($updates)): ?>
          <div class="card empty" data-aos="zoom-in">Belum ada berita terbaru.</div>
        <?php else: foreach($updates as $i => $u):
          $aos = ($i % 3 === 0) ? 'fade-up' : (($i % 3 === 1) ? 'fade-right' : 'fade-left');
        ?>
        <article class="card" data-aos="<?= $aos ?>" data-aos-delay="<?= ($i*80) ?>">
          <div class="title"><?= htmlspecialchars($u['title']) ?></div>
          <div class="date"><?= htmlspecialchars($u['date']) ?></div>
          <div class="body"><?= htmlspecialchars($u['body']) ?></div>
          <div class="tag"><?= htmlspecialchars($u['tag']) ?></div>
        </article>
        <?php endforeach; endif; ?>
      </div>
    </section>
    <div style="margin-top:20px; display:flex; gap:12px; align-items:center; justify-content:space-between; flex-wrap:wrap;">
      <div style="display:flex;gap:12px;align-items:center">
        <small style="color:var(--muted)">Mau kirim pengumuman? Tambahin entri di file ini atau implementasikan tabel updates di DB.</small>
      </div>
      <div>
        <a class="pill" href="index.php" style="text-decoration:none;cursor:pointer">Kembali ke Chat</a>
      </div>
    </div>
  </main>
  <footer class="footer">
    © <?= date('Y') ?> ChitChat · ZennDev
  </footer>
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script src="js/update.js"> </script>
</body>
</html>
